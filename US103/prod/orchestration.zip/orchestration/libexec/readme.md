This folder contains "helper" scripts that are called by other scripts in bin directories.  

I decided to put the sitecode at the start of each to make reading the scripts easier in the future as I intend on expanding this codebase to other sites/services (AWS, Azure, etc).